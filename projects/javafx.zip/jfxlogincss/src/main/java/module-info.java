module edu.uwf.cs.acp.jfxlogincss {
    requires javafx.controls;
    exports edu.uwf.cs.acp.jfxlogincss;
}