package app;

import hello1.Hello;
// import hello2.HelloHidden;

public class Speak {

	public static void main(String[] args) {
		Hello.say();
//		HelloHidden.say();
	}

}
