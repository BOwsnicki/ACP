package rental;

public class Car {
	private double carWeight;
	private String carColor;

	public String getColor() {
		return carColor;
	}

	public double getWeight() {
		return carWeight;
	}

	public void setColor(String newColor) {
		carColor = newColor;
	}

	public void setWeight(double newWeight) {
		carWeight = newWeight;
	}
}