package hello2;

public class HelloHidden {
	public static void say() {
		System.out.println("Hallo, Welt!");
	}
}
