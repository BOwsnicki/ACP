package factory.classes;

public class Bicycle implements Vehicle {
	@Override
	public int maxSpeed() {
		return 30;
	}

}
