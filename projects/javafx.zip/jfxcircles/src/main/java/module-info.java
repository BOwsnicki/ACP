module edu.uwf.cs.acp.jfxcircles {
    requires javafx.controls;
    exports edu.uwf.cs.acp.jfxcircles;
}