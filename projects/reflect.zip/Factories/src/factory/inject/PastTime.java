package factory.inject;

import factory.classes.Vehicle;

public abstract class PastTime {
	protected Vehicle v;

	public Vehicle getVehicle() {
		return v;
	}
}
