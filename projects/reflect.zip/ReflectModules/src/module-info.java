module ReflectModules {
	exports person;
	exports rental;
	opens person to ReflectDemos;
}