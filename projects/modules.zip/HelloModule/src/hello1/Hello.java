package hello1;

public class Hello {
	public static void say() {
		System.out.println("Hello, world!");
	}
}
