module edu.uwf.cs.acp.jfxlogin {
    requires javafx.controls;
    exports edu.uwf.cs.acp.jfxlogin;
}