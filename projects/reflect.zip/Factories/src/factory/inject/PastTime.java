package factory.inject;

import factory.classes.Vehicle;

public abstract class PastTime {
	private Vehicle v;

	public Vehicle getVehicle() {
		return v;
	}
}
