package factory.inject;

public class Biking extends PastTime {

	public Biking() {
		super();
	}
}
