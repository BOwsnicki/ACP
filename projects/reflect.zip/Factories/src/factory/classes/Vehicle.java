package factory.classes;

public interface Vehicle {
	int maxSpeed();
}
