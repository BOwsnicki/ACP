package app;

import hello1.Hello;

public class Speak {

	public static void main(String[] args) {
		Hello.say();
	}

}
