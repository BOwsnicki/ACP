package person;

public class Person {
    private String hairColor = "brown";
    public String getHairColor() {
        return hairColor;
    }
}
