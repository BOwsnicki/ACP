module edu.uwf.cs.acp.jfxfiles {
    requires javafx.controls;
    exports edu.uwf.cs.acp.jfxfiles;
}