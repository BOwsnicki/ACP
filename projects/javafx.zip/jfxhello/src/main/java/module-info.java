module edu.uwf.cs.acp.jfxhello {
    requires transitive javafx.controls;
    exports edu.uwf.cs.acp.jfxhello;
}