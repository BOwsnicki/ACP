module HelloModule {
	exports hello1;
}