module HelloApp {
	requires HelloModule;
}