module edu.uwf.cs.acp.jfxlayout {
    requires javafx.controls;
	requires javafx.base;
	requires transitive javafx.graphics;
	
    exports edu.uwf.cs.acp.jfxlayout;
}