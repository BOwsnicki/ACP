module edu.uwf.cs.acp.jfxlissajous {
    requires javafx.controls;
    exports edu.uwf.cs.acp.jfxlissajous;
}