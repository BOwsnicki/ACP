package factory.inject;

public class Racing extends PastTime {

	public Racing() {
		super();
	}
}
