package factory.classes;

public class Ferrari implements Vehicle {
	@Override
	public int maxSpeed() {
		return 200;
	}
}
